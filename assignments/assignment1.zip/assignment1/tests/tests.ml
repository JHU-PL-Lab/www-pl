open OUnit2
open Assignment

(*
  This file contains a few tests but not necessarily complete coverage.  You are
   encouraged to think of more tests if needed for the corner cases.
   We will cover the details of the test syntax but with simple copy/paste it should
   not be hard to add new tests of your own without knowing the details.
   1) Write a new let which performs the test, e.g. let test_nth_exn_2 _ = ...
   2) Add that let-named entity to one of the test suite lists such as section1_tests
      by adding e.g.
       "nth 2"       >:: test_nth_exn_2;

   Thats it! OR, even easier, just add another `assert_equal` to the existing tests.
   They will not be submitted with the rest of your code, so you may alter this file as you wish.

   Recall that you need to type "dune test" to your shell to run the test suite.
*)

(* SECTION 1 *)

let test_nth_exn _ =
  assert_equal (nth_exn 0 [ 1; 2; 3; 4 ]) 1;
  assert_equal (nth_exn 3 [ 1; 2; 3; 4 ]) 4;
  assert_equal (nth_exn 1 [ "Voyage"; "Shipwreck"; "Salvage" ]) "Shipwreck"

let test_for_all _ =
  assert_equal (for_all (fun n -> n > 0) [ 0; 1; 2; 3 ]) false;
  assert_equal (for_all (fun b -> not b) [ false; false ]) true;
  assert_equal (for_all (fun n -> n = 0) []) true;
  assert_equal (for_all (fun _ -> false) []) true

let test_list_map _ =
  assert_equal (list_map (fun n -> (n * 2) - 1) [ 2; 4; 6; 8 ]) [ 3; 7; 11; 15 ];
  assert_equal
    (list_map
       (fun l -> for_all (fun n -> n > 0) l)
       [ [ 0; 1; 2 ]; [ 3; 4; 5 ]; [ 6; 7; 8 ] ])
    [ false; true; true ]

let test_transpose _ =
  assert_equal
    (transpose [ [ 1; 2; 3; 4 ]; [ 4; 3; 2; 1 ] ])
    [ [ 1; 4 ]; [ 2; 3 ]; [ 3; 2 ]; [ 4; 1 ] ];
  assert_equal
    (transpose [ [ 1; 2 ]; [ 3; 4 ]; [ 5; 6 ]; [ 7; 8 ] ])
    [ [ 1; 3; 5; 7 ]; [ 2; 4; 6; 8 ] ]

let section1_tests =
  "Section 1"
  >: test_list
       [
         "nth_exn" >:: test_nth_exn;
         "for_all" >:: test_for_all;
         "list_map" >:: test_list_map;
         "transpose" >:: test_transpose;
       ]

(* SECTION 2 *)

let test_fetch_val _ =
  assert_equal (fetch_val [ [ 1; 2; 3 ]; [ 4; 5; 6 ]; [ 7; 8; 9 ] ] (0, 0)) 1;
  assert_equal (fetch_val [ [ 1; 2; 3 ]; [ 4; 5; 6 ]; [ 7; 8; 9 ] ] (2, 1)) 8

let test_sort_int_list _ =
  assert_equal (sort_int_list [ 1; 3; 5; 4; 2; 6 ]) [ 1; 2; 3; 4; 5; 6 ];
  assert_equal (sort_int_list []) []

(* This grid is correctly solved, and satisfies the inequality relations provided. *)

let test_grid =
  [ [ 1; 2; 4; 3 ]; [ 4; 3; 2; 1 ]; [ 3; 4; 1; 2 ]; [ 2; 1; 3; 4 ] ]

let test_neq_pairs =
  [
    ((0, 0), (0, 1));
    ((1, 3), (2, 3));
    ((2, 0), (2, 1));
    ((3, 0), (2, 0));
    ((3, 2), (3, 3));
  ]

(* This grid satisfies the sudoku property, but violates one of the inequalities *)

let test_grid_bad =
  [ [ 1; 2; 3; 4 ]; [ 2; 3; 4; 1 ]; [ 3; 4; 1; 2 ]; [ 4; 1; 2; 3 ] ]

let test_neq_pairs_bad =
  [ ((0, 0), (1, 0)); ((1, 0), (2, 0)); ((2, 0), (1, 3)) ]

let test_verify_solution _ =
  assert_equal (verify_solution 4 test_neq_pairs test_grid) true;
  assert_equal (verify_solution 4 test_neq_pairs_bad test_grid_bad) false

let section2_tests =
  "Section 2"
  >: test_list
       [
         "fech_val" >:: test_fetch_val;
         "sort" >:: test_sort_int_list;
         "verify_solution" >:: test_verify_solution;
       ]

let series = "Assignment1 Tests" >::: [ section1_tests; section2_tests ]
let () = run_test_tt_main series
