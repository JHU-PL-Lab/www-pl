
open OUnit2
open Assignment

(* 
  This file contains a few tests but not necessarily complete coverage.  You are
   encouraged to think of more tests if needed for the corner cases. 
   We will cover the details of the test syntax but with simple copy/paste it should 
   not be hard to add new tests of your own without knowing the details.
   1) Write a new let which performs the test, e.g. let test_gcd_2 _ = ...
   2) Add that let-named entity to one of the test suite lists such as section1_tests
      by adding e.g. 
       "GCD 2"       >:: test_gcd_2;
       
   Thats it! OR, even easier, just add another `assert_equal` to the existing tests.
   They will not be submitted with the rest of your code, so you may alter this file as you wish.

   Recall that you need to type "dune test" to your shell to run the test suite.
*)

let test_factorial _ =
  assert_equal (factorial 0) 1;
  assert_equal (factorial 3) 6;
  assert_equal (factorial 7) 420


let test_fibonacci _ =
  assert_equal (fibonacci 0) 0;
  assert_equal (fibonacci 1) 1;
  assert_equal (fibonacci 10) 55
  

let test_choose _ =
  assert_equal (choose 2 1) 2;
  assert_equal (choose 2 2) 1;
  assert_equal (choose 7 3) 35
  
let test_gcd _ =
  assert_equal (gcd 1000 1001) 1;
  assert_equal (gcd 20 10) 10
  
let section1_tests =
  "Section 1" >: test_list [
    "Factorial" >:: test_factorial;
    "Fibonacci" >:: test_fibonacci;
    "Choose"    >:: test_choose;
    "GCD"       >:: test_gcd;
  ]
  

let test_iota _ =
  assert_equal (iota 5) [1; 2; 3; 4; 5];
  assert_equal (iota 0) []

let test_zip _ =
  assert_equal (zip [1; 2; 3] ["a"; "b"; "c"]) [(1, "a"); (2, "b"); (3, "c")];
  assert_equal (zip [] []) []

let test_zip_with _ =
  assert_equal (zip_with (+) [1; 2; 3] [-1; -2; -3]) [0; 0; 0];
  assert_equal (zip_with (^) ["a"; "b"; "c"] ["1"; "2"; "3"]) ["a1"; "b2"; "c3"];
  assert_equal (zip_with (fun x () -> x) [None] [()]) [None]

let section2_tests =
  "Section 2" >: test_list [
    "Iota"    >:: test_iota;
    "Zip"     >:: test_zip;
    "ZipWith" >:: test_zip_with;
  ]


let test_every_nth _ =
  assert_equal (every_nth 2 (iota 10)) [1; 3; 5; 7; 9];
  assert_equal (every_nth 3 (iota 10)) [1; 4; 7];
  assert_equal (every_nth 10 ["a"; "b"]) ["a"]

let test_ping_pong _ =
  assert_equal (ping_pong [1; 2; 3; 4; 5; 6]) [1; 6; 2; 5; 3; 4];
  assert_equal (ping_pong ["a"; "b"; "c"]) ["a"; "c"; "b"]


let test_filter_nones _ =
  assert_equal (filter_nones [None; None; None; None; None]) [];
  assert_equal (filter_nones [Some(3); None; Some(10); Some(20)]) [3; 10; 20];
  assert_equal (filter_nones [None; Some("a")]) ["a"]


let test_compose_funs _ =
  assert_equal (compose_funs [(fun x -> x + 1); (fun y -> y * 2)] 10) 21;
  assert_equal (compose_funs [(fun l -> 1 :: l); (fun l -> 2 :: l)] []) [1; 2]

let test_is_prime _ =
  assert_equal (is_prime 2) true;
  assert_equal (is_prime 4) false;
  assert_equal (is_prime 271) true


let test_prime_factors _ =
  assert_equal (prime_factors 40) [2; 2; 2; 5];
  assert_equal (prime_factors 33) [3; 11]


let test_hyper _ =
  assert_equal (hyper 0 5 7) (7 + 1);
  assert_equal (hyper 1 5 7) (5 + 7);
  assert_equal (hyper 2 5 7) (5 * 7);
  assert_equal (hyper 3 5 7) (int_of_float (5. ** 7.))

let section3_tests = 
  "Section 3" >: test_list [
    "EveryNth"     >:: test_every_nth;
    "PingPong"     >:: test_ping_pong;
    "FilterNones"  >:: test_filter_nones;
    "ComposeFuns"  >:: test_compose_funs;
    "IsPrime"      >:: test_is_prime;
    "PrimeFactors" >:: test_prime_factors;
    "Hyper"        >:: test_hyper;
  ]



let series =
  "Assignment1 Tests" >::: [
    section1_tests;
    section2_tests;
    section3_tests;
  ]

let () = 
  run_test_tt_main series

