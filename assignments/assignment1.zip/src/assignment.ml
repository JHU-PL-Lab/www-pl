(*

PL Assignment 1
 
Name                  : 
List of Collaborators :

Please make a good faith effort at listing people you discussed any 
problems with here, as per the course academic integrity policy.  
CAs/Prof need not be listed!

Fill in the function definitions below replacing the 

  unimplemented ()

with your code.  Feel free to add "rec" to any function listed to make
it recursive. In some cases, you will find it helpful to define
auxillary functions, feel free to.

Several of the questions below involve computing well-known mathematical functions;
if you are not familiar with the function named your trusty search engine
should be able to give you an answer, and feel free to ask on Piazza.

You must not use any mutation operations of OCaml for any of these
questions (which we have not taught yet in any case): no arrays,
for- or while-loops, references, etc.

*)

(* Disables "unused variable" warning from dune while you're still solving these! *)
[@@@ocaml.warning "-27"]

(* Here is a simple function which gets passed unit, (), as argument
   and raises an exception.  It is the initial implementation below. *)

let unimplemented () =
	failwith "unimplemented"
	
(*
	Section 1: simple numeric recursions.
	
	All functions must be total for the specified domain;
	overflow is excluded from this restriction but should be avoided.
	
*)

(*
	Given a non-negative integer `n`, compute n factorial.
*)
let factorial (n: int): int =
	unimplemented ()

(*
	Given a non-negative integer `n`, compute the n-th fibonacci number.
	This should not take exponential time (the naive version from lecture is exponential).
	Use the convention that fib(0) = 0, fib(1) = 1.
*)
let fibonacci (n: int): int =
    unimplemented ()

(*
	Given non-negative integers `n` and `k`, compute the mathematical function `n choose k`.
*)
let choose (n: int) (k: int): int =
	unimplemented ()

(*
	Given non-negative integers `n` and `m`, compute their greatest common denominator.
*)
let gcd (n: int) (m: int): int =
	unimplemented ()


(*
	Section 2: building lists.	The List module functions such as List.fold_left 
	may NOT be used in any questions in this section.
*)
	
(*
	Given a non-negative integer `n`, produce a list [1; 2; ...; n-1; n].
*)
let iota (n: int): int list =
	unimplemented ()
	
	
(*
	Given lists `l1` and `l2`, produce a list containing the pairwise elements in a tuple.
	You can assume the lists are of equal length.

	E.G.
		zip [1; 2; 3] ["a"; "b"; "c"] = [(1, "a"); (2, "b"); (3, "c")]
*)
let zip (l1: 'a list) (l2: 'b list): ('a * 'b) list =
	unimplemented ()

(*
	Given a function `f` and two lists `l1` and `l2`, produce a list
	containing the results of applying `f` on the pairwise elements of the lists.
	You can assume the lists are of equal length.

	E.G.
		zip_with (+) [1; 2; 3] [-1; -2; -3] = [0; 0; 0]
*)
let zip_with (f: 'a -> 'b -> 'c) (l1: 'a list) (l2: 'b list) : 'c list =
	unimplemented ()


(*
	Section 3: More lists.	The List module functions again may NOT be used.
*)

(*
	Given a list `l`, and a positive integer `n`, return every `n`-th element of `l`,
	skipping the ones between, starting with the first one.

	E.G. every_nth 2 (iota 10) = [1; 3; 5; 7; 9]
			 every_nth 3 (iota 10) = [1; 4; 7]
*)
let every_nth (n: int) (l: 'a list) : 'a list =
	unimplemented ()


(*
	Given a list `l`, make a list which contains elements taken alternatingly
	from the front and back of `l`, i.e. the first, last, second, second-to-last, etc.

	E.G. ping_pong [1; 2; 3; 4; 5; 6] = [1; 6; 2; 5; 3; 4]
	     ping_pong ["a"; "b"; "c"] = ["a"; "c"; "b"]
*)
let ping_pong (l: 'a list) : 'a list =
	unimplemented ()


(*
	Given a list of optional values, filter out the values which are None
	to produce a non-optional value list.

	E.G.
		filter_nones [Some(3); None; Some(10); None; None] = [3; 10]
*)
let filter_nones (l: 'a option list) : 'a list =
	unimplemented ()


(*
	Given a list of functions, produce the function which is a result
	of composing the functions together in order.  
	E.G. 
		compose_funs [f; g; h] x = f (g (h x))
*)
let compose_funs (fs: ('a -> 'a) list) : ('a -> 'a) =
	unimplemented ()


(*
	Given a positive integer `n`, determine whether it is prime.
*)
let is_prime (n: int): bool = 
	unimplemented ()


(*
	Given a positive integer `n`, produce the ascending list of the prime factors of n.
	Each prime factor should appear as many times as it divides into `n`, so that
	multiplying together the resulting list recovers the original input.

	E.G.
		prime_factors 20 = [2; 2; 5]
		prime_factors 33 = [3; 11]
*)
let prime_factors (n: int): int list = 
	unimplemented ()


(*
	Given non-negative integers `n`, `a`, `b`, compute the Hyperoperator function "a[n]b":
	see https://en.wikipedia.org/wiki/Hyperoperation for details.
*)
let hyper (n: int) (a: int) (b: int) : int =
	unimplemented ()