(*

PL Assignment 2
 
Name                  : 
List of Collaborators :

Please make a good faith effort at listing people you discussed any 
problems with here, as per the course academic integrity policy.  
CAs/Prof need not be listed!

Fill in the function definitions below replacing the 

  unimplemented ()

with your code.  Feel free to add "rec" to any function listed to make
it recursive. In some cases, you will find it helpful to define
auxillary functions, feel free to.

You must not use any mutation operations of OCaml for any of these
questions: no arrays, for- or while-loops, references, etc.

Note that you *can* use List.map etc library functions on this homework.

*)

(* Disables "unused variable" warning from dune while you're still solving these! *)
[@@@ocaml.warning "-27"]

(* Here is again our unimplemented "BOOM" function for questions you have not yet answered *)

let unimplemented _ =
	failwith "unimplemented"

(* 
  Section 1: Thinking like a type inferencer

  To better understand OCaml's parametric types, you are to write functions that return the indicated types.  

  Note you can ignore the lists of type variables at the front of the types in the below, e.g. 
  the `'a 'b 'c 'd.` in the `f1` type; those are OCaml notation meaning those types *have* to
  be polymorphic.  We have answered the first question for you to make it clear.

*)

let f0 : 'a. 'a -> int = (fun _ -> 4) (* answered for you *)

let f1 : 'a 'b 'c 'd. 'a -> 'b -> 'c -> 'd -> unit
  = unimplemented

let f2 : 'a. 'a list -> int -> 'a
  = unimplemented

let f3 : 'a 'b. 'a -> ('a -> 'b) -> 'b
  = unimplemented

let f4 : 'a 'b 'c. ('a -> 'b) -> ('a -> 'c) -> 'a -> 'b * 'c
  = unimplemented

let f5 : 'a 'b. 'a -> 'b -> ('a * 'b) list
  = unimplemented

type ('a, 'b) sometype = 
  | Foo of 'a 
  | Bar of 'b

let f6 : 'a 'b 'c 'd. ('a * 'b) list -> ('a -> 'b -> 'c) -> ('d, 'c) sometype list 
  = unimplemented

let f7 : 'a 'b 'c. ('a -> 'b -> int -> 'c) -> 'a -> ('a -> 'b) -> 'c
  = unimplemented

(* 
  Section 2 : An ode to being lazy

   Lazy programming languages don't evaluate components of lists so it is possible to write an
   "infinite" list via OCaml pseudo-code such as

   let rec mklist n = n :: (mklist (n+1));;
   mklist 0;;

   Now, if you typed this into OCaml the `mklist 0` would unfortunately loop forever.

   **But**, if you "froze" the computation of the tail of the list by making it a 
   function, we can achieve something in this lazy spirit.

   We will give you the type of lazy sequences to help you get going on this question:
*)
type 'a sequence =
  | Nil 
  | Sequence of 'a * (unit -> 'a sequence)

(* 
  This is similar to the list type; the difference is the `unit ->` which keeps 
  the tail of the list from running by making it a function.
  Here for example is how you would write an infinite sequence of zeroes:
*)
let rec zeroes = 
  Sequence(0, fun () -> zeroes)

(* 
  It is still possible to express finite lists as sequences,
  for example here is [1; 2] as a sequence, with `Nil` denoting the empty sequence.
*)
let one_and_two = 
  Sequence(1, fun () -> Sequence(2, fun () -> Nil))

(*
  Write a function to convert a sequence to a list. Of course if you try to 
  evaluate this on an infinite sequence such as `zeroes` above, it will not finish. 
  But we will assume sanity on the caller's part and ignore that issue in this question.
  E.G.
   list_of_sequence one_and_two = [1; 2]
*)
let list_of_sequence (s: 'a sequence) : 'a list = 
  unimplemented ();;

(*
  While it is nice to have these infinite sequences, it is often useful to "cut" 
  them to a fixed size. Write a function that cuts off a sequence after a fixed 
  non-negative number of values `n`, producing a new, potentially shorter sequence.
  
  (Treat the given count `n` as the maximum number of elements allowed in the 
  output sequence. So if the input is a finite sequence and its length is less
  than the specified count, the output sequence can have less than `n` values)
  
  E.G. 
    list_of_sequence (cut_sequence 5 zeroes) = [0; 0; 0; 0; 0]
*)
let cut_sequence n (s: 'a sequence) : 'a sequence = 
  unimplemented ();;


(*
  You can also encode finite sequences directly using the above type. 
  For this question encode the sequence corresponding to a geometric 
  progression given an initial value, the end value (exclusive) and the common
  factor (the step size of the sequence), given as positive integers.
  (Here is some background on geometric progressions: 
   https://en.wikipedia.org/wiki/Geometric_progression)

  E.G.
    list_of_sequence (gp 1 12 3) = [1; 3; 9]
    list_of_sequence (gp 2 20 2) = [2; 4; 8; 16]
*)	
let gp initv endv step : int sequence = 
  unimplemented ()


(*
  Now write two infinite sequences: one of factorials, one of triangle numbers.
  (see https://en.wikipedia.org/wiki/Triangular_number if needed for the latter)

  E.G.
    list_of_sequence (cut_sequence 8 factorials) = 
      [1; 1; 2; 6; 24; 120; 720; 5040]

    list_of_sequence (cut_sequence 10 triangles) = 
      [0; 1; 3; 6; 10; 15; 21; 28; 36; 45]
*)
let factorials : int sequence 
  = Nil

let triangles : int sequence 
  = Nil
	
(*
  Write a filter-map function which takes a function and a sequence as input 
  and returns a new sequence where the values have been mapped using the input
  function and potentially dropped.

  Note that if the filter part always returns None and the input sequence is infinite,
  this function will not terminate. Ignore this issue.
*)

let filter_map_sequence (f: 'a -> 'b option) (s: 'a sequence) : 'b sequence =
    unimplemented ()

(*
  Write a map function (analogous to List.map)
  using your implementation of filter_map_sequence.

  E.G.
    list_of_sequence 
      (map_sequence (fun x -> x + 3) (gp 2 10 2)) 
      = [5; 7; 11]
*)
let map_sequence (fn : 'a -> 'b) (s : 'a sequence) : 'b sequence 
  = unimplemented ()

(*
  Write a filter function (analogous to List.filter)
  using your implementation of filter_map_sequence.

  E.G.
    list_of_sequence
      (filter_sequence (fun x -> x mod 3 = 2) (gp 2 12 2)) 
      = [2; 8]
    
    (triangles
    |> filter_sequence (fun x -> x mod 5 = 0)
    |> cut_sequence 4
    |> list_of_sequence) 
      = [0; 10; 15; 45]
*)
let filter_sequence (fn : 'a -> bool) (s : 'a sequence) : 'a sequence = 
  unimplemented ()


(* Section 3: n-ary trees

The following data type can be used to represent a tree
with variable numbers of children. Each node stores an element of
type 'a. Each node also holds a list of 'a trees. When this list is
empty, then the Node is a leaf node. *)

type 'a n_tree = Node of 'a * 'a n_tree list;;

(* Here is a tree that you can use for simple tests of your functions. *)

let atree = 
    Node (1, [ 
      Node (2, [
        Node (3, []);
        Node (4, []);
        Node (5, [Node (6, [])]);
        Node (7, []);
      ]); 
      Node (8, []);
    ]);;

(* 
  Write a function list_to_tree which converts an arbitrary list to a tree 
  where each 'a n_tree list is a singleton list. 
  Note that n_tree lacks a completely empty tree case in the type;
  use invalid_arg appropriately if the input list is empty.
*)
let list_to_tree (l: 'a list) : 'a n_tree = 
  unimplemented ()

(* 
  Now write the inverse of the above, again raising invalid_arg
  for the case that the n_tree has any non-singleton nodes.
*)
let linear_tree_to_list (tree : 'a n_tree) : 'a list = 
  unimplemented ()

(*
  Fact: for any non-empty list l, linear_tree_to_list @@ list_to_tree l = l 
*)


(* 
  Write a function to apply a function to each element in the tree.
  This is similar to the map function that can be applied to lists. Your
  function will return a new tree where each element has been
  transformed according to the specified function.
  
  E.G. 
    tree_map (fun x -> x*10) atree =
      Node (10, [
        Node (20, [
          Node (30, []);
          Node (40, []); 
          Node (50, [Node (60, [])]); 
          Node (70, []);
        ]);
        Node (80, []);
      ])
*)
let tree_map (f: 'a -> 'b) (tree: 'a n_tree) : 'b n_tree = 
  unimplemented ()

(* 
  Write a function to see if *any* element in the tree passes a test.
  This function will take a test function and apply this function to
  each data element in the tree. If the test function returns true on
  any application, then the exists_in_tree function should return true.
  Otherwise it should return false.
  
  E.G.
    exists_in_tree (function x -> x = 6) atree  = true
    exists_in_tree (function x -> x = 4) atree  = true
    exists_in_tree (function x -> x > 10) atree = false
*)
let exists_in_tree (f: 'a -> bool) (tree: 'a n_tree) = 
  unimplemented ()

(* 
  Suppose that someone encodes a tree by writing a list of tuples.
  The first element is the data that is stored in the node, and the
  second is the number of children. The children trees are listed
  immediately after their parent nodes. 

  For example, the list

    [("a",2); ("b",2); ("c",0); ("d",0); ("e",1); ("f",1); ("g",0)]    

  represents:

            a
          /   \
        b     e
      /  \    |
     c    d   f
              |
              g 

  The Node with "a" is the root and has two children, and so on.

  Write a function that takes a list that encodes a tree and returns the tree.
*)
let decode_tree (l: ('a * int) list) : 'a n_tree = 
  unimplemented ()

let coded_tree = [(1,2);(2,4);(3,0);(4,0);(5,1);(6,0);(7,0);(8,0)];; 

(* E.G. decode_tree coded_tree = atree *)
