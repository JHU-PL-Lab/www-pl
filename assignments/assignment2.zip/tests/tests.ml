
open OUnit2
open Assignment

(* 
  This file contains a few tests but not necessarily complete coverage.  You are
   encouraged to think of more tests if needed for the corner cases. 
   We will cover the details of the test syntax but with simple copy/paste it should 
   not be hard to add new tests of your own without knowing the details.
   1) Write a new let which performs the test, e.g. let test_gcd_2 _ = ...
   2) Add that let-named entity to one of the test suite lists such as section1_tests
      by adding e.g. 
       "GCD 2"       >:: test_gcd_2;
       
   Thats it! OR, even easier, just add another `assert_equal` to the existing tests.
   They will not be submitted with the rest of your code, so you may alter this file as you wish.

   Recall that you need to type "dune test" to your shell to run the test suite.
*)


let test_function_types _ =
  let _ = f1 () [] "a" 10 in
  let _ = f2 [1; 10; 100] 200 in
  let _ = f3 10 string_of_int in
  let _ = f4 (fun x -> x * 10) string_of_int 100 in
  let _ = f5 1.0 ["1.0"] in
  let _ = f6 [(1, 2); (3, 4)] (+) in
  let _ = f7 (fun _ _ _ -> ()) "10" int_of_string in
  ()
let section1_tests =
  "Section1" >::: [
    "FunctionTypes" >:: test_function_types;
  ]


let test_list_of_sequence _ =
  assert_equal [1; 2]      (list_of_sequence one_and_two);
  assert_equal [0;0;0;0;0] (list_of_sequence (cut_sequence 5 zeroes));
  assert_equal [1; 3; 9]   (list_of_sequence (gp 1 12 3));
  assert_equal [2;4;8;16]  (list_of_sequence (gp 2 20 2));
  assert_equal [1;1;1;1;1] (list_of_sequence (cut_sequence 5 (gp 1 2 1)))
  

let test_factorials _ =
  assert_equal [1; 1; 2; 6; 24; 120; 720; 5040]
    (list_of_sequence (cut_sequence 8 factorials))
    

let test_triangles _ =
  assert_equal [0; 1; 3; 6; 10; 15; 21; 28; 36; 45]
    (list_of_sequence (cut_sequence 10 triangles)) 
    

let test_map_sequence _ =
  assert_equal [5; 7; 11] 
    (gp 2 10 2
    |> map_sequence (fun x -> x + 3)
    |> list_of_sequence);
  assert_equal ["a1"; "a1"; "a2"; "a6"]
    (factorials
    |> map_sequence (fun x -> "a" ^ string_of_int x)
    |> cut_sequence 4
    |> list_of_sequence)


let test_filter_sequence _ =
  assert_equal [2; 8]
    (gp 2 12 2
    |> filter_sequence (fun x -> x mod 3 = 2)
    |> list_of_sequence);
  assert_equal [0; 10; 15; 45]
    (triangles
    |> filter_sequence (fun x -> x mod 5 = 0)
    |> cut_sequence 4
    |> list_of_sequence) 

  
let section2_tests = 
  "Section2" >::: [
    "ListOfSequence" >:: test_list_of_sequence;
    "Factorials"     >:: test_factorials;
    "Triangles"      >:: test_triangles;
    "MapSequence"    >:: test_map_sequence;
    "FilterSequence" >:: test_filter_sequence;
  ]


let test_list_to_tree _ =
  assert_equal (Node (1, [])) (list_to_tree [1]);
  assert_equal (Node (1, [Node (2, [])])) (list_to_tree [1; 2])

let test_linear_tree_to_list _ =
  assert_equal [1] (linear_tree_to_list (Node (1, [])));
  assert_equal [1; 2; 3]
    ( Node (1, [Node (2, [Node (3, [])])])
    |> linear_tree_to_list)


let atree =
  Node (1, [ 
    Node (2, [
      Node (3, []);
      Node (4, []);
      Node (5, [Node (6, [])]);
      Node (7, []);
    ]); 
    Node (8, []);
  ])

let test_tree_map _ =
 assert_equal (tree_map (fun x -> x*10) atree) @@
    Node (10, [
      Node (20, [
        Node (30, []);
        Node (40, []); 
        Node (50, [Node (60, [])]); 
        Node (70, []);
      ]);
      Node (80, []);
    ]);
  assert_equal (tree_map string_of_int atree) @@
    Node ("1", [ 
      Node ("2", [
        Node ("3", []);
        Node ("4", []);
        Node ("5", [Node ("6", [])]);
        Node ("7", []);
      ]); 
      Node ("8", []);
    ])


let test_exists_in_tree _ =
  assert_equal true (exists_in_tree (fun x -> x = 6) atree);
  assert_equal true (exists_in_tree (fun x -> x = 4) atree);
  assert_equal false (exists_in_tree (fun x -> x = 20) atree);
  assert_equal true
    (factorials
    |> cut_sequence 10
    |> list_of_sequence
    |> list_to_tree
    |> exists_in_tree (fun x -> x > 3000000))


let coded_tree =
  [("a",2);("b",2);("c",0);("d",0);("e",1);("f",1);("g",0)]

let test_decode_tree _ =
  assert_equal (decode_tree coded_tree) @@
    Node ("a", [
      Node ("b", [
        Node ("c", []);
        Node ("d", []);
      ]);
      Node ("e", [
        Node ("f", [
          Node ("g", []);
        ]);
      ]);
    ])

let section3_tests =
  "Section3" >::: [
    "ListToTree"   >:: test_list_to_tree;
    "TreeToList"   >:: test_linear_tree_to_list;
    "TreeMap"      >:: test_tree_map;
    "ExistsInTree" >:: test_exists_in_tree;
    "DecodeTree"   >:: test_decode_tree;
  ]

let series =
  "Assignment" >::: [
    section1_tests;
    section2_tests;
    section3_tests;
  ]

let () = 
  run_test_tt_main series

