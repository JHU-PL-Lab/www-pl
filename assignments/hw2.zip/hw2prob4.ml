exception ChainError of string;;

let ones = Chain.read Chain.infones 10;;
let sum = List.fold_left (+) 0 ones;;
if sum = 10 then () else raise (ChainError("failed to add ones"));;

let ints = Chain.read (Chain.rightof Chain.integers) 10;;
let sum = List.fold_left (+) 0 ints;;
if sum = 55 then () else raise (ChainError("failed to add ints"));;

let fib2 = Chain.right_n Chain.fib 2;;
if Chain.read fib2 6 = [1;2;3;5;8;13] then () else raise (ChainError("fibonacci chain is incorrect!"));;

let squares = Chain.map Chain.integers (fun x -> x*x) ;;
let sum = List.fold_left (+) 0 (Chain.read squares 5);;
if sum = 30 then () else raise (ChainError("failed to add squares"));;

let idxfib = Chain.combine Chain.integers Chain.fib;;
let idxfibsnip = Chain.read idxfib (-5);;
if idxfibsnip = [(-4,-3);(-3,2);(-2,-1);(-1,1);(0,0)] then () else raise (ChainError("combine failed"));;

(*
(* You can enable this portion of the code if you want to test the bonus
   problem 4b. *)
let evens = Chain.filter Chain.integers (fun x -> x mod 2 = 0);;
let evens_snip = Chain.read evens  10;;
if evens_snip = [0;2;4;6;8;10;12;14;16;18] then () else raise (ChainError("filter failed"));;
*)

print_string "Success\n";;