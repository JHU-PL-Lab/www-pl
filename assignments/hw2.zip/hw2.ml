(*
600.426 - Programming Languages
JHU Spring 2011
Homework 2

In this source file, you will find a number of comments containing the text
"ANSWER".  Each of these comments indicates a portion of the source code you
must fill in yourself.  You are welcome to include other functions for use in
your answers.  Read the instructions for each problem and supply a segment of
code which accomplishes the indicated task.  For your convenience, a number of
test expressions are provided for each problem as well as a description of
their expected values.

In this assignment, you are permitted to complete the listed tasks using any
of the OCaml module functions you please.  You are still required to avoid the
use of mutation.
*)


(* ****************************** Problem 1 ****************************** *)

(*
For the next several problems, you will be asked to produce an expression which
has a given type.  It does not matter what expression you provide as long as it
has that type; there may be numerous (or even infinite) answers for each
question.  Your answer may *not* produce a compiler warning.  You are *not*
permitted to use explicit type annotations (such as "fun x:'a -> x").
*) 

(*
Problem 1a. (2 points)

Give an expression which has the following type: string list
*)
let prob1a = ();; (* ANSWER *)

(*
Problem 1b. (2 points)

Give an expression which has the following type: unit * unit
*)
let prob1b = ();; (* ANSWER *)

(*
Problem 1c. (2 points)

Give an expression which has the following type: bool list list array
*)
let prob1c = ();; (* ANSWER *)

(*
Problem 1d. (2 points)

Give an expression which has the following type: 'a -> 'a -> bool
*)
let prob1d = ();; (* ANSWER *)

(*
Problem 1e. (2 points)

Give an expression which has the following type: int -> 'a list
*)
let prob1e = ();; (* ANSWER *)

(*
Problem 1f. (2 points)

Give an expression which has the following type: ('a list -> 'a list) list -> 'a list
*)
let prob1f = ();; (* ANSWER *)

(*
Problem 1g. (2 points)

Give an expression which has the following type: 'a * 'b * 'c -> int
*)
let prob1g = ();; (* ANSWER *)

(*
Problem 1h. (2 points)

Give an expression which has the following type: ('a -> 'b) -> ('a -> 'c) -> 'a -> 'b * 'c
*)
let prob1h = ();; (* ANSWER *)

(*
Problem 1i. (2 points)

Give an expression which has the following type: 'a list -> 'b list -> 'c list -> ('a * 'b * 'c) list
*)
let prob1i = ();; (* ANSWER *)

(*
Problem 1j. (2 points)

Give an expression which has the following type: foo -> foo list
*)
let prob1j = ();; (* ANSWER *)


(* ****************************** Problem 2 ****************************** *)

(*
Problem 2a. (10 points)
 
In this problem, we will use OCaml's types to create chains of infinite size.
Further, these chains are not lists: they will not have a head and they will
expand infinitely in both directions.  The following type defines a cell in
this infinite chain:
*)

type 'a infchain = InfCell of ((unit -> 'a infchain) * 'a * (unit -> 'a infchain));;

(* 
The meaning of this type is as follows: a Cell(before,value,after) is a
position in the chain which has data "value".  If unit (also known as the
zero-tuple -- a tuple of zero elements -- which is represented as "()") is
passed either the "before" function or the "after" function, the infchain cell
which is returned is the element before or after (respectively) the current
cell.  For instance, consider the following definition of an infinitely sized
chain of ones:
*)

let rec infones = InfCell((fun () -> infones), 1, (fun () -> infones));;

(*
The middle value in the cell is the actual one.  The "before" and "after"
functions both return the same cell; this is because, in an infinite chain of
ones, the cells to the left and right look exactly the same as the current
cell.

For this problem, define an infinite chain of integers.  The chain should
descend toward the left and ascend toward the right.  The actual value of the
integers variable should be at the position in the chain which represents 0.
*)

let integers = ();; (* ANSWER *)

(*
# let InfCell(b,x,a) = integers in x;;
- : int = 0
# let InfCell(b,x,a) = integers in (b ());;
- : int inflist = InfCell (<fun>, -1, <fun>)
# let InfCell(b,x,a) = integers in (a ());;
- : int inflist = InfCell (<fun>, 1, <fun>)
# let InfCell(b,x,a) = integers in let InfCell(b',x',a') = (a ()) in a' ();;
- : int inflist = InfCell (<fun>, 2, <fun>)
*)


(* 
Problem 2b. (5 points)

Write two functions: one which moves left on an infinite chain and the other
which moves right.
*)

let leftof chain = ();; (* ANSWER *)
let rightof chain = ();; (* ANSWER *)

(*
# leftof integers;;
- : int infchain = InfCell (<fun>, -1, <fun>)
# rightof integers;;
- : int infchain = InfCell (<fun>, 1, <fun>)
# leftof (leftof (leftof integers));;
- : int infchain = InfCell (<fun>, -3, <fun>)
*)


(*
Problem 2c. (5 points)

Now, write a function which takes another function, a count (N), and an
argument.  It should compose that function with itself N times and then apply
the result to the argument.  This function should raise an exception (of a
sensible type of your choice) if a negative N is provided.

Then, use that function to write two more chain functions: one to move left N
spaces on the chain and another to move right N spaces on a chain.
*)

let compose_n f n x = ();; (* ANSWER *)
let left_n chain n = ();; (* ANSWER *)
let right_n chain n = ();; (* ANSWER *)

(*
# left_n integers 3;;
- : int infchain = InfCell (<fun>, -3, <fun>)
# right_n integers 7;;
- : int infchain = InfCell (<fun>, 7, <fun>)
# left_n infones 0;;
- : int infchain = InfCell (<fun>, 1, <fun>)
# right_n integers (-1);;
Exception: BadIndex.
*)

(*
Problem 2d. (5 points)

Write a function which can extract (as a list) a sequence of values from an
infinite chain.  The function should take two arguments: the chain and the
number of items to extract.  If the number of items is negative, this indicates
the retrieval of elements to the left; otherwise, it indicates retrieval of
elements to the right.  It should always return a list such that the first
element in the list is the leftmost element which was retrieved from the chain.
*)

let chainread chain num = ();; (* ANSWER *)

(*
# chainread integers 10;;
- : int list = [0; 1; 2; 3; 4; 5; 6; 7; 8; 9]
# chainread integers (-10);;
- : int list = [-9; -8; -7; -6; -5; -4; -3; -2; -1; 0]
# chainread infones 10;;
- : int list = [1; 1; 1; 1; 1; 1; 1; 1; 1; 1]
# chainread (right_n integers 3) (-7);;
- : int list = [-3; -2; -1; 0; 1; 2; 3]
# chainread integers 0;;
- : int list = []
*)


(*
Problem 2e. (10 points)

Define a chain representing the Fibonacci sequence.  The 0th position of the
Fibonacci sequence is the value 0.  Fibonacci numbers are also defined for the
negative numbers as well.  For more information, see:
    http://en.wikipedia.org/wiki/Fibonacci_number#List_of_Fibonacci_numbers
As with the last chain, the value of the "fibchain" variable itself should
point to the 0th fibonacci number.
*)

let fibchain = ();; (* ANSWER *)

(*
# chainread fibchain 7;;
- : int list = [0; 1; 1; 2; 3; 5; 8]
# chainread fibchain (-7);;
- : int list = [-8; 5; -3; 2; -1; 1; 0]
# chainread (left_n fibchain 11) 23;;
- : int list = [89; -55; 34; -21; 13; -8; 5; -3; 2; -1; 1; 0; 1; 1; 2; 3; 5; 8; 13; 21; 34; 55; 89]
*)


(*
Problem 2f. (10 points)

Now that we have this concept of an infinite chain (as well as a few functions
that operate over infinite chains), write a function called "chainmap" which
will take a chain node and return a chain node that has that function applied
to each of its (infinitely many) members.  You will obviously not be able to
do this eagerly, as doing so would take infinite time.  "chainmap" should take
a chain node and a function as its arguments; its behavior is analogous to
List.map.
*)

let chainmap chain f = ();; (* ANSWER *)

(*
# chainread (chainmap integers (fun x -> x * 2)) 10;;
- : int list = [0; 2; 4; 6; 8; 10; 12; 14; 16; 18]
# chainread (chainmap fibchain (fun x -> -x)) 10;;
- : int list = [0; -1; -1; -2; -3; -5; -8; -13; -21; -34]
# chainread (chainmap integers (fun x -> x mod 2 = 0)) 10;;
- : bool list = [true; false; true; false; true; false; true; false; true; false]
# chainread (chainmap fibchain (fun x -> x mod 2 = 0)) 10;;
- : bool list = [true; false; false; true; false; false; true; false; false; true]
*)


(*
Problem 2g. (5 points)

Next, write a function "combine" that takes two chains and produces a single
chain where each value in the new chain is a 2-tuple between the values in the
old chains.
*)

let chaincombine chain1 chain2 = ();; (* ANSWER *)

(*
# chainread (chaincombine integers infones) 9;;
- : (int * int) list = [(0, 1); (1, 1); (2, 1); (3, 1); (4, 1); (5, 1); (6, 1); (7, 1); (8, 1)]
# chainread (chaincombine integers fibchain) 9;;
- : (int * int) list = [(0, 0); (1, 1); (2, 1); (3, 2); (4, 3); (5, 5); (6, 8); (7, 13); (8, 21)]
# chainread (chainmap (chaincombine integers fibchain) (fun (intv,fibv) -> (float(fibv))/.(float(intv)))) 9;;
- : float list = [nan; 1.; 0.5; 0.66666666666666663; 0.75; 1.; 1.33333333333333326; 1.85714285714285721; 2.625]
*)


(* ****************************** Problem 3 ****************************** *)

(*
Problem 3a. (5 points)

There are two ways to use modules in OCaml.  The first is to "open" them (as in
"open List;;"), which allows you to access the contents of the module using
simple names (such as "rev").  The second is to use the contents of the module
by qualified name (such as "List.rev").  I would strongly recommend the second
form; opening modules very quickly leads to a cluttered namespace.

For this problem, write a function which accepts a list of strings.  It should
return the same list in reversed order such that the first letter has been
removed from each string (if possible).  The OCaml library reference will be
handy: http://caml.inria.fr/pub/docs/manual-ocaml/libref/index.html

Hint: my implementation is about six lines long.  I used four different module
functions.
*)

let prob3a strings = ();; (* ANSWER *)

(*
# prob3a ["hello";"world"];;
- : string list = ["orld"; "ello"]
# prob3a ["this";"is";"a";"test";""];;
- : string list = [""; "est"; ""; "s"; "his"]
# prob3a [];;
- : string list = []
*)


(*
Problem 3b. (10 points)

Using functors will make your life considerably easier in Homework 3.  To this
end, you will make use of the Set.Make functor here.  Set.Make takes a module
as input which meets the signature OrderedType: it has a type t and a function
compare.  (See the OCaml library reference for more information.)  For
instance, the following invocation of that functor creates a module which
operates over ints:
*)

module IntSet = Set.Make(
	struct
		type t = int
		let compare x y = x - y
	end);;

(*
The "struct" and "end" terms define a module with a type "t" and a function
"compare"; the Set.Make functor uses these to create an IntSet module that can
then be used to create sets of integers.

For this problem, use the Set.Make functor to create a Set module that stores
strings.  It should, however, treat all strings with a length longer than 3 as
equivalent to their three-character prefix (such as might occur in very, very
old BASIC interpreters for variable names).  That is, "took" and "tool" are
considered the same value.
*)

module Var3Set = struct end;; (* ANSWER *)

(*
# let s1 = Var3Set.empty;;
val s1 : Var3Set.t = <abstr>
# Var3Set.elements s1;;
- : Var3Set.elt list = []
# let s2 = Var3Set.add "monkey" s1;;
val s2 : Var3Set.t = <abstr>
# Var3Set.elements s2;;
- : Var3Set.elt list = ["monkey"]
# let s3 = Var3Set.add "monster" (Var3Set.add "tesla coil" (Var3Set.add "naegleria" s1));;
val s3 : Var3Set.t = <abstr>
# Var3Set.elements s3;;
- : Var3Set.elt list = ["monster"; "naegleria"; "tesla coil"]
# let s4 = Var3Set.add "test" s3;;
val s4 : Var3Set.t = <abstr>
# Var3Set.elements s4;;
- : Var3Set.elt list = ["monster"; "naegleria"; "tesla coil"]
# let s5 = Var3Set.union s2 s4;;
val s5 : Var3Set.t = <abstr>
# Var3Set.elements s5;;
- : Var3Set.elt list = ["monster"; "naegleria"; "tesla coil"]
*)


(* ****************************** Problem 4 ****************************** *)

(*
Problem 4a. (15 points)

Now that you know how to use modules, you will learn how to create them.  This
template came with a file called "hw2prob4.ml" which does not yet compile.  You
will write a module file "chain.ml" and a module interface file "chain.mli"
which will provide a library containing your implementations of the infinite
chain tasks from Problem 2.  After creating these files correctly, "hw2prob4.ml"
will compile and should run without raising any exceptions.  You are *NOT*
permitted to modify "hw2prob4.ml" to complete this problem.

Your program should be compiled with ocamlc; you should not be using the OCaml
toploop for this problem.  In Eclipse with an ocamlbuild project, this can be
accomplished by opening the project's Properties dialog, clicking Project, and
adding "hw2prob4.byte" to the list of targets.  Contact the instructor or TA if
you have any questions related to building the homework.

You should alter the names of your functions in the module to eliminate
redundancy:
		
		(prob2name)  ==> (name which appears in the module interface)
		
		infchain     ==> chain
		
		infones      ==> infones
		integers     ==> integers
		leftof       ==> leftof
		rightof      ==> rightof
		left_n       ==> left_n
		right_n      ==> right_n
		
		chainread    ==> read
		fibchain     ==> fib
		chainmap     ==> map
		chaincombine ==> combine

Do not expose your "compose" function through your module interface.  If you
wish to avoid exposing the InfChain constructor, you should also provide
"construct" and "destruct" functions.  They have the following signatures:

		construct : ((unit -> 'a chain) * 'a * (unit -> 'a chain)) -> 'a chain
		destruct : 'a chain -> ((unit -> 'a chain) * 'a * (unit -> 'a chain))

As always, let us know if you have any questions.
*)


(*
Problem 4b. (10 BONUS POINTS - you are not required to do this problem.)

Add to your Chain module and module interface a function called "filter" which
accepts an 'a chain and a function 'a -> boolean.  It should return a chain
which contains only those values in the original chain for which the function
returns true.  This is analogous to List.filter.
*)
