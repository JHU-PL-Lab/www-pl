(* Open the Module containing the expr type *)

open Fbextast;;

exception NotClosed
exception BuggyInterpreter

let rec eval e = e;;
  
