open Fbast;;

(*
 * Replace this with your typechecker code.  Your code should not throw the
 * following exception; if you need to raise an exception, create your own
 * exception type here.
 *) 
let typecheck e = raise Fbdk.TypecheckerNotImplementedException;;