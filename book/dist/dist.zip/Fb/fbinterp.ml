open Fbast

(*
 * Replace this with your interpreter code.
 *)
let eval e = e
