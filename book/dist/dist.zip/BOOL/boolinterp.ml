open Boolast

(*
 * Replace this with your interpreter code.
 *)
let eval e = e
