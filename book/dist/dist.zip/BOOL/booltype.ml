
exception TypecheckerNotImplementedException;;

let typecheck _ = 
  raise TypecheckerNotImplementedException;;

let typecheck_default_enabled = 
  false;;