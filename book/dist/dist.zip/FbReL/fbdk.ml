
let name = "FbReL"

module Parser = Fbrelparser
module Lexer = Fbrellexer
module Ast = Fbrelast
module Pp = Fbrelpp
module Options = Fbreloptions
module Interpreter = Fbrelinterp
module Typechecker = Fbreltype
module Version = Version

