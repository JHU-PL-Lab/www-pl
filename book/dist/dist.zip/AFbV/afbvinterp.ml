open Afbvast;;

(* Replace with your code here *)
let eval e = e ;;
