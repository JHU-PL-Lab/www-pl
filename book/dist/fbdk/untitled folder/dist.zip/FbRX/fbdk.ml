
let name = "FbRX"

module Parser = Fbrxparser
module Lexer = Fbrxlexer
module Ast = Fbrxast
module Pp = Fbrxpp
module Options = Fbrxoptions
module Interpreter = Fbrxinterp
module Typechecker = Fbrxtype
module Version = Version

