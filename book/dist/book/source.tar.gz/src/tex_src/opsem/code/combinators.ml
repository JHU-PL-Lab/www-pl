(* First some abbreviations to save finger wear *)

let i s = Ident s            (* abbreviation for identifiers *)
let v s = Var(Ident s)       (* abbreviation for variables *)

(* Shorthand for common ident/var names *)

let ix = i"x" (* ident x *)
let vx = v"x" (* variable x *)
let iy = i"y" (* ident y *)
let vy = v"y" (* variable y *)
let iz = i"z" (* ident z *)
let vz = v"z" (* variable z *)
let il = i"l" (* ident l *)
let vl = v"l" (* variable l *)
let ir = i"r" (* ident r *)
let vr = v"r" (* variable r *)

(* The classic pure functional combinators *)

let id = Function(ix,vx)                        (* I x = x *)
let k = Function(ix,Function(iy,vx))            (* K x y = x *)
let s = Function(ix,Function(iy,Function(iz,    (* S x y z =     *)
          Appl(Appl(vx,vz),(Appl(vy,vz))))))    (*   (x z) (y z) *)
let d = Function(ix, Appl(vx,vx))               (* D x = x x *)
