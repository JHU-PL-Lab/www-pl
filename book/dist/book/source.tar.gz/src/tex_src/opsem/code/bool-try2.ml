let rec eval exp = 
  match exp with 
    | True -> True
    | False -> False
    | And(exp0,exp1) ->
      begin
        match (eval exp0, eval exp1) with
          | (True,True) -> True
          | (_,False) -> False
          | (False,_) -> False
      end
