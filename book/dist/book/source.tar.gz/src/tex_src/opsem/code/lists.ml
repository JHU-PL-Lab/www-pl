let head = left
let tail = right
let emptylist = (Int 0)
let cons = pr
let length = Letrec(i"Length",ix,
    If(Equal(vx,emptylist),(Int 0),Plus(Appl(v"Length",tl(vx)),
        (Int 1))))));
