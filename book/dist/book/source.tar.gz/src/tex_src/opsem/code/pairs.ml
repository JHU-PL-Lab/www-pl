(* Constructs a pair with left element l and right element r *)

let pr (l,r) = Function(ix, Appl(Appl(vx, l), r))

(* Operations for projections *)

let left e =  Appl(e,Function(ix,Function(iy,vx)))
let right e = Appl(e,Function(ix,Function(iy,vy)))
