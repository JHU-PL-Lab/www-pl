type boolexp =
    True | False |
    Not of boolexp |
    And of boolexp * boolexp |
    Or of boolexp * boolexp |
    Implies of boolexp * boolexp;;