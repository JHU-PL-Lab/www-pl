(* Declare all the expr, etc types globally for convenience. *)

(* The store functionality is a separate module.  *)

module type STORE = 
  sig
   (* ... *)
  end

(* The Store structure implements a (functional) store.  A simple
 * implementation could be via a list of pairs such as
 *
 *   [((Cell 2),(Int 4)); ((Cell 3),Plus((Int 5),(Int 4))); ... ]
 *)

module Store : STORE =

type store = (* ... *)

 struct
  let empty = (* initial empty store *)
  let fresh = (* returns a fresh Cell name *)
    let count = ref 0 in
    function () -> ( count := !count + 1; Cell(!count) )
  (* Note: this is not purely functional!  It is quite  
   * difficult to make fresh purely functional.
   *)

(* Look up value of cell c in store s *)
   let lookup (s,c) = (* ... *)

(* Add or modify cell c to point to value v in the store s.
 * Return the new store.
 *)
   let modify(s,c,v) =  (* ... *)
  end

(* The evaluator is then a functor taking a store module *)

module FbSEvalFunctor =
  functor (Store : STORE) ->
  struct
    
    (* ... *)


    let eval (e,s) = match e with 
      (Int n) -> ((Int n),s) (* values don't modify store *)
    | Plus(e,e') -> 
        let (Int n,s') = eval(e,s) in
        let (Int n',s'') = eval(e',s') in
        (Int (n+n'),s'')
        
(* Other cases such as application use a similar store 
 * threading technique.
 *)
    | Ref(e) -> let (v,s') = eval(e,s) in
                let c = Store.fresh() in
                   (c,Store.modify(s',c,v))
    | Get(e) -> let (Cell(n),s') = eval(e,s) in
      (Store.lookup(Cell(n)),s')
    | Set(e,e') ->  (* exercise *)

  end

module FbSEval = FbSEvalFunctor(Store)
