/*
 * Define the type `Word' to be a generic one-word value.
 */
typedef void *Word;

/* 
 * Define the type `FPtr' to be a pointer to a function that
 * consumes Word and returns a Word.  All translated
 * functions should be of this form.  
 */
typedef Word (*FPtr)(Word);

/*
 * Here is an example of how to use these typedefs in code.
 */
Word my_function(Word w) {
  return w;
}
int main(int argc, char **argv) {
  Word f1 = (Word) my_function;
  Word w1 = (Word) 123;
  Word w2 = ( *((FPtr) f1) )(w1); /* Computes f1(123) */
  printf("%d\n", (int) w2);       /* output is "123\n". */
  return 0;
}

