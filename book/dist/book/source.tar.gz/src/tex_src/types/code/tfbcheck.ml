let rec typecheck gamma e = 
  match e with
    (* look up first mapping of x in list gamma *)
    Var x -> lookup gamma x 
  | Function(Ide x,t,e) ->
      let t' = typecheck (((Ide x),t)::gamma) e in 
      Arrow(t,t') 
  | Appl(e1,e2) -> 
      let Arrow(t1,t2) = typecheck gamma e1 in
      if typecheck gamma e2 = t1 then
        t2 
      else 
        raise TypeError 
  | Plus(e1,e2) -> 
      if typecheck gamma e1 = Int and 
         typecheck gamma e2 = Int then
        Int 
      else 
        raise TypeError 
  | (* \ldots *)
