type expr = 
    Var of ident 
  | Function of ident * fbtype * expr
  | Letrec of ident * ident * fbtype * expr * fbtype * expr
  | Appl of expr * expr
  | Plus of expr * expr | Minus of expr * expr 
  | Equal of expr * expr | And of expr * expr
  | Or of expr * expr | Not of expr 
  | If of expr * expr * expr | Int of int | Bool of bool 
  | Ref of expr | Set of expr * expr | Get of expr 
  | Cell of int | Record of (label * expr) list 
  | Select of  label * expr | Raise of expr * fbtype |
  | Try of expr * string * ident * expr 
  | Exn of string * expr

and fbtype = 
    Int | Bool | Arrow of fbtype * fbtype 
  | Rec of label * fbtype list | Rf of fbtype | Ex of fbtype
