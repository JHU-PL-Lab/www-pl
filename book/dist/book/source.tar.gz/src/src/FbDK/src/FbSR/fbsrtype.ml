open Fbsrast;;

let typecheck e = raise Fbdk.TypecheckerNotImplementedException;;