let typecheck e = raise Fbdk.TypecheckerNotImplementedException;;
let typecheck_default_enabled = false;;